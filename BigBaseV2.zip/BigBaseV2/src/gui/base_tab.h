#pragma once

#include "common.hpp"
#include "natives.hpp"

namespace big
{
	class base_tab
	{
	public:
		static void render_base_tab();
	};
}